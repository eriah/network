#include "cwork.h"
  
Pack data;
int main()
{
  	int id = 1;
	time_t t_start,t_end;
	struct sockaddr_in server_addr;
    int client_socket_fd = client_init(&server_addr);
	int server_addr_length = sizeof(struct sockaddr_in);

	char newfn[FILE_NAME_MAX_SIZE+1];
 	send_filename(client_socket_fd, newfn, &server_addr);
	t_start=time(NULL);

	/* 打开文件，准备接收 */
  	FILE *fp = fopen(newfn, "w");
  	if(NULL == fp){
    exit(1);
  }
  /* 接收数据，写入文件 */
  	int len = 0;

  	while(1)
  	{
    	PackInfo pack_info;  
    	if((len = recvfrom(client_socket_fd
						, (char*)&data, sizeof(data), 0
						, (struct sockaddr*)&server_addr
						, &server_addr_length)) > 0){
		
      	if(data.head.id == id){		
        	pack_info.id = data.head.id;
        	pack_info.buf_size = data.head.buf_size;
        	++id;
       
			/* 发送数据包确认信息 */
        	if(sendto(client_socket_fd
					, (char*)&pack_info
					, sizeof(pack_info)
					, 0, (struct sockaddr*)&server_addr
					, server_addr_length) < 0){
         	 printf("Send confirm information failed!");
        	}
			/* 如果收到的是空包，则表示已传输完成 */
			if(data.head.buf_size==0)
				break;

       	/* 写入文件 */
        	if(fwrite(data.buf, sizeof(char), data.head.buf_size, fp) < data.head.buf_size){
          		break;
        	}
			else{			
			}
      	}
	  	/* 如果是重发的包 */
      	else if(data.head.id < id) 
      	{
        	pack_info.id = data.head.id;
        	pack_info.buf_size = data.head.buf_size;
       
        if(sendto(client_socket_fd
				, (char*)&pack_info
				, sizeof(pack_info)
				, 0, (struct sockaddr*)&server_addr
				, server_addr_length) < 0)//重发数据包确认信息
        {
          printf("Send confirm information failed!");
        }
      }    
    }
  }
	
	t_end=time(NULL);
  	printf("THE TIME IS:%.0fs\n",difftime(t_end,t_start));
  	fclose(fp);
  	close(client_socket_fd);
  	return 0;
}

