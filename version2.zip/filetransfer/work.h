#ifndef _WORK_H__
#define _WORK_H__

#include<sys/types.h>
#include<sys/socket.h>
#include<unistd.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<stdio.h>
#include<stdlib.h>
#include<errno.h>
#include<netdb.h>
#include<stdarg.h>
#include<string.h>
  
#define SERVER_PORT 8000
#define BUFFER_SIZE 16384
#define FILE_NAME_MAX_SIZE 1024

typedef struct
{
	int id;
	int buf_size;
}PackInfo;

typedef struct 
{
	PackInfo head;
    char buf[BUFFER_SIZE];
}Pack;


/* 初始化server */
int server_init();

/* 读取文件名 */
void get_filename(int server_socket_fd, char file_name[] ,struct sockaddr_in *client_addr);

#endif
