#include "work.h"

/* server init */
int server_init()
{
	struct sockaddr_in server_addr;//创建套接字
	bzero(&server_addr, sizeof(server_addr));
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	server_addr.sin_port = htons(SERVER_PORT);
	int server_socket_fd = socket(AF_INET, SOCK_DGRAM, 0);
	if(server_socket_fd == -1)
	{
		perror("Create Socket Failed:");
		exit(1);
	}


	if(-1 == (bind(server_socket_fd,(struct sockaddr*)&server_addr,sizeof(server_addr))))//绑定套接字
	{
		perror("Server Bind Failed:");
		exit(1);
	}
	return server_socket_fd;
}


void get_filename(int server_socket_fd, char file_name[] ,struct sockaddr_in *client_addr)
{

	socklen_t client_addr_length = sizeof(struct sockaddr_in);

	char buffer[BUFFER_SIZE];//接受数据
	bzero(buffer, BUFFER_SIZE);
	if(recvfrom(server_socket_fd, buffer, BUFFER_SIZE,0,(struct sockaddr*)client_addr, &client_addr_length) == -1)
	{
		perror("Receive Data Failed:");
		exit(1);
	}

	/* 从buffer中读取文件名 */
	bzero(file_name,FILE_NAME_MAX_SIZE+1);
	strncpy(file_name, buffer, strlen(buffer)>FILE_NAME_MAX_SIZE? FILE_NAME_MAX_SIZE : strlen(buffer));
	printf("File:%s Is Sending...\n", file_name);
}

