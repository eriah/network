#include "cwork.h"

int client_init(struct sockaddr_in *server_addr)
{
	bzero(server_addr, sizeof(server_addr));
	server_addr->sin_family = AF_INET;
  	server_addr->sin_addr.s_addr = inet_addr("127.0.0.1");
	server_addr->sin_port = htons(SERVER_PORT);
  	socklen_t server_addr_length = sizeof(server_addr);

  	int client_socket_fd = socket(AF_INET, SOCK_DGRAM, 0);
  	if(client_socket_fd < 0)
  	{
    	perror("Create Socket Failed:");
    	exit(1);
  	}
	return client_socket_fd;
}
 
void send_filename(int client_socket_fd, char newfn[] ,struct sockaddr_in *server_addr)
{
	char file_name[FILE_NAME_MAX_SIZE+1];//输入文件名到缓冲
  	bzero(file_name, FILE_NAME_MAX_SIZE+1);
  	printf("Please Input File Name : ");
  	scanf("%s", file_name);
	printf("File:%s Is Receiving...\n",file_name);

  	char buffer[BUFFER_SIZE];
  	bzero(buffer, BUFFER_SIZE);
  	strncpy(buffer, file_name, strlen(file_name)>BUFFER_SIZE?BUFFER_SIZE:strlen(file_name));
  
  	sprintf(newfn,"%s","new_");
  
  	if(sendto(client_socket_fd, buffer, BUFFER_SIZE,0,(struct sockaddr*)server_addr,server_addr_length) < 0)       //发送文件名
  	{
    	perror("Send File Name Failed:");
    	exit(1);
  	}
	strcat(newfn,file_name);
}
