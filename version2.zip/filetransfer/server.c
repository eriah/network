#include "work.h"

Pack data;
int main()
{
	/* 初始化server */
	int server_socket_fd = server_init();
	
	/* 读取文件名 */
	struct sockaddr_in client_addr;
	char file_name[FILE_NAME_MAX_SIZE+1];
	get_filename(server_socket_fd, file_name, &client_addr);

	/* 文件发送 */
	FILE *fp = fopen(file_name, "r");
	int send_id = 0;
	int receive_id = 0;
	socklen_t client_addr_length = sizeof(struct sockaddr_in);
	if(NULL == fp)
	{
		printf("File:%s Not Found.\n", file_name);
	}
	else
	{
		int len = 1;
		int finish=0;
		while(1){
			PackInfo pack_info;
			if(receive_id == send_id){
				++send_id;
				if(finish==0){
					if(len>0){
						/* 发送id放进包头,用于标记顺序 */
						len = fread(data.buf, sizeof(char), BUFFER_SIZE, fp);
						data.head.id = send_id;
						data.head.buf_size = len;
					        if(sendto(server_socket_fd
									, (char*)&data
									, sizeof(data), 0
									, (struct sockaddr*)&client_addr
									, client_addr_length) < 0){
							perror("Send File Failed:");
							break;
							}
						recvfrom(server_socket_fd
								, (char*)&pack_info
								, sizeof(pack_info), 0
								, (struct sockaddr*)&client_addr
								, &client_addr_length);
						receive_id = pack_info.id; 
					}
					/* 如果上一个发送的是空包，且已确认，则结束该文件的传输 */
					else{
						finish=1;
						--send_id;
					}
				}
				else{
					break;
				}
			}
			else{
				/* 如果接收的id和发送的id不相同,重新发送 */
				if(sendto(server_socket_fd
						, (char*)&data, sizeof(data), 0
						, (struct sockaddr*)&client_addr
						, client_addr_length) < 0)	{
					perror("Send File Failed:");
					break;
				}
				recvfrom(server_socket_fd
						, (char*)&pack_info
						, sizeof(pack_info), 0
						, (struct sockaddr*)&client_addr
						, &client_addr_length);
				receive_id = pack_info.id; 
			}
		}

		fclose(fp);
		printf("File:%s Is Finish!\n", file_name);
	}

	close(server_socket_fd);
	return 0;
} 

